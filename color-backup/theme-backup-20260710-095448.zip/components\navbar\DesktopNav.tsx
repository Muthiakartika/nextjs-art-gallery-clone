import Link from "next/link";
import { NAV_ITEMS } from "@/components/navbar/navItems";
import MegaPanel from "@/components/navbar/MegaPanel";
import { ChevronDownIcon } from "@/components/ui/icons";

export default function DesktopNav() {
  return (
    <nav className="hidden lg:block" aria-label="Primary">
      <ul className="flex items-center gap-8">
        {NAV_ITEMS.map((item) => (
          <li key={item.label} className="group relative">
            <Link
              href={item.href}
              className="inline-flex items-center gap-1 text-[15px] font-medium text-neutral-800 transition-colors hover:text-[#8a5a3c]"
            >
              {item.label}

              {item.columns && (
                <ChevronDownIcon className="h-3.5 w-3.5 text-neutral-400 transition-transform duration-200 group-hover:rotate-180" />
              )}
            </Link>

            {item.columns && <MegaPanel columns={item.columns} />}
          </li>
        ))}
      </ul>
    </nav>
  );
}